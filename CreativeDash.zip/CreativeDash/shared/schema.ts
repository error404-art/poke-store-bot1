import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Order schema for the PokeMMO store
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  discordUserId: text("discord_user_id").notNull(),
  discordUsername: text("discord_username").notNull(),
  pokeMMOCharacter: text("pokemmo_character").notNull(),
  age: integer("age").notNull(),
  product: text("product").notNull(),
  quantity: integer("quantity").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  discordUserId: true,
  discordUsername: true,
  pokeMMOCharacter: true,
  age: true,
  product: true,
  quantity: true,
});

// Server configuration for the bot
export const serverConfig = pgTable("server_config", {
  id: serial("id").primaryKey(),
  guildId: text("guild_id").notNull().unique(),
  orderChannelId: text("order_channel_id"),
  requiredRoleId: text("required_role_id"),
});

export const insertServerConfigSchema = createInsertSchema(serverConfig).pick({
  guildId: true,
  orderChannelId: true,
  requiredRoleId: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export type InsertServerConfig = z.infer<typeof insertServerConfigSchema>;
export type ServerConfig = typeof serverConfig.$inferSelect;
