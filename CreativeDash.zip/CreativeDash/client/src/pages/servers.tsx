
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  AlertCircle, 
  Server,
  Users, 
  Settings,
  ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function Servers() {
  const [, setLocation] = useLocation();
  
  // Server interface
  interface Server {
    id: string;
    name: string;
    icon: string | null;
    memberCount: number;
    joined: string;
    config: {
      id: number;
      guildId: string;
      orderChannelId?: string;
      requiredRoleId?: string;
    } | null;
  }

  // Query servers list
  const { data: servers, isLoading, error } = useQuery<Server[]>({
    queryKey: ['/api/servers'],
    refetchInterval: 60000,
  });

  // Check if bot is connected
  const { data: status } = useQuery({
    queryKey: ['/api/status'],
    refetchInterval: 30000,
  });

  if (!status?.connected) {
    return (
      <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
        <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Bot Desconectado</AlertTitle>
            <AlertDescription>
              El bot no está conectado a Discord. Por favor, espera mientras se reconecta...
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
        <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
          <header className="mb-8">
            <h1 className="text-2xl font-bold mb-4">Servidores de Discord</h1>
            <p className="text-discord-textSecondary">
              Cargando servidores donde está presente el bot...
            </p>
          </header>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="relative overflow-hidden">
                <CardHeader className="pb-2">
                  <div className="flex items-center space-x-2">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-1">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
        <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              Ocurrió un error al cargar los servidores. Por favor, intenta nuevamente.
            </AlertDescription>
          </Alert>
          <Button variant="default" onClick={() => window.location.reload()}>
            Recargar
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
      <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
        <header className="mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold">Servidores de Discord</h1>
              <p className="text-discord-textSecondary">
                Configura el bot para cada servidor
              </p>
            </div>
            <Button 
              variant="default" 
              className="mt-2 md:mt-0"
              onClick={() => setLocation("/")}
            >
              Volver al Inicio
            </Button>
          </div>
          <Separator className="my-4" />
        </header>

        {servers?.length === 0 ? (
          <div className="bg-discord-secondary rounded-lg p-8 text-center">
            <Server className="h-12 w-12 mx-auto text-discord-textSecondary mb-4" />
            <h2 className="text-xl font-semibold mb-2">No hay servidores disponibles</h2>
            <p className="text-discord-textSecondary mb-4">
              {servers?.length === 0 
                ? "El bot no está presente en ningún servidor actualmente. Invítalo a tu servidor para comenzar a configurarlo."
                : "No se encontraron servidores donde tengas permisos para configurar el bot."}
            </p>
            <Button 
              variant="default"
              onClick={() => window.open("https://discord.com/api/oauth2/authorize?client_id=" + process.env.DISCORD_CLIENT_ID + "&permissions=8&scope=bot%20applications.commands", "_blank")}
            >
              Invitar Bot a un Servidor
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {servers?.map((server) => (
              <Card key={server.id} className="hover:bg-discord-tertiary/10 transition-colors">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      {server.icon ? (
                        <img 
                          src={server.icon} 
                          alt={server.name} 
                          className="h-10 w-10 rounded-full"
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-discord-blurple flex items-center justify-center">
                          <span className="text-white font-bold">
                            {server.name.substring(0, 2)}
                          </span>
                        </div>
                      )}
                      <div>
                        <h3 className="font-medium text-discord-textPrimary">{server.name}</h3>
                        <div className="flex items-center text-xs text-discord-textSecondary">
                          <Users className="h-3 w-3 mr-1" />
                          <span>{server.memberCount} miembros</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-discord-textSecondary">
                      Unido: {new Date(server.joined).toLocaleDateString('es-ES')}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <Badge variant={server.config ? "default" : "outline"} className="mb-2">
                      {server.config ? "Configurado" : "No configurado"}
                    </Badge>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-discord-textSecondary" 
                      onClick={() => setLocation(`/server/${server.id}`)}
                    >
                      <Settings className="h-4 w-4 mr-1" />
                      Configurar
                      <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
