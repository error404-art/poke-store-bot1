import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import BotStatus from "@/components/BotStatus";
import ConfigPanel from "@/components/ConfigPanel";

export default function Home() {
  const [activeTab, setActiveTab] = useState("configuration");
  const [, setLocation] = useLocation();
  
  // Query bot status
  const { data: botStatus, isLoading, error } = useQuery({
    queryKey: ['/api/status'],
    refetchInterval: 30000, // refresh every 30 seconds
  });

  return (
    <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
      <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
        <header className="mb-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center mb-4 md:mb-0">
              <div className="bg-discord-blurple p-2 rounded-full mr-3">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19.27 5.33C17.94 4.71 16.5 4.26 15 4a.09.09 0 0 0-.07.03c-.18.33-.39.76-.53 1.09a16.09 16.09 0 0 0-4.8 0c-.14-.34-.35-.76-.54-1.09-.01-.02-.04-.03-.07-.03-1.5.26-2.93.71-4.27 1.33-.01 0-.02.01-.03.02-2.72 4.07-3.47 8.03-3.1 11.95 0 .02.01.04.03.05 1.8 1.32 3.53 2.12 5.24 2.65.03.01.06 0 .07-.02.4-.55.76-1.13 1.07-1.74.02-.04 0-.08-.04-.09-.57-.22-1.11-.48-1.64-.78-.04-.02-.04-.08-.01-.11.11-.08.22-.17.33-.25.02-.02.05-.02.07-.01 3.44 1.57 7.15 1.57 10.55 0 .02-.01.05-.01.07.01.11.09.22.17.33.26.04.03.04.09-.01.11-.52.31-1.07.56-1.64.78-.04.01-.05.06-.04.09.32.61.68 1.19 1.07 1.74.03.02.06.03.09.02 1.72-.53 3.45-1.33 5.25-2.65.02-.01.03-.03.03-.05.44-4.53-.73-8.46-3.1-11.95-.01-.01-.02-.02-.04-.02zM8.52 14.91c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12 0 1.17-.84 2.12-1.89 2.12zm6.97 0c-1.03 0-1.89-.95-1.89-2.12s.84-2.12 1.89-2.12c1.06 0 1.9.96 1.89 2.12 0 1.17-.83 2.12-1.89 2.12z"/>
                </svg>
              </div>
              <h1 className="text-2xl font-bold">PokeStore Discord Bot</h1>
            </div>
            <div className="flex space-x-2">
              <a 
                href="https://railway.app/new" 
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-[#0B0D0E] hover:bg-opacity-80 text-white py-2 px-4 rounded flex items-center gap-2"
              >
                <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8.2 19.7001L15.9 24.1001L23.7 19.7001L15.9 15.3001L8.2 19.7001Z" fill="#fff"/>
                  <path d="M15.9 8.3999L8.2 12.8999L15.9 17.2999L23.7 12.8999L15.9 8.3999Z" fill="#fff"/>
                </svg>
                Desplegar en Railway
              </a>
              <a 
                href="https://discord.js.org/"
                target="_blank" 
                rel="noopener noreferrer"
                className="bg-discord-tertiary hover:bg-opacity-80 text-discord-textPrimary py-2 px-4 rounded"
              >
                Documentación
              </a>
            </div>
          </div>
        </header>

        {!import.meta.env.VITE_DISCORD_BOT_TOKEN && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Token del Bot Faltante</AlertTitle>
            <AlertDescription>
              No se encontró el token del bot de Discord. Agrega DISCORD_BOT_TOKEN a tus variables de entorno.
            </AlertDescription>
          </Alert>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-discord-secondary rounded-t-lg p-1 flex space-x-1 border-b border-discord-tertiary">
            <TabsTrigger 
              value="configuration" 
              className={activeTab === "configuration" ? "bg-discord-primary text-discord-textPrimary py-2 px-4 rounded-t-lg font-medium" : "text-discord-textSecondary py-2 px-4 rounded-t-lg hover:bg-discord-primary hover:bg-opacity-50"}
            >
              Configuración
            </TabsTrigger>
            <TabsTrigger 
              value="permissions" 
              className={activeTab === "permissions" ? "bg-discord-primary text-discord-textPrimary py-2 px-4 rounded-t-lg font-medium" : "text-discord-textSecondary py-2 px-4 rounded-t-lg hover:bg-discord-primary hover:bg-opacity-50"}
            >
              Permisos
            </TabsTrigger>
            <TabsTrigger 
              value="logs" 
              className={activeTab === "logs" ? "bg-discord-primary text-discord-textPrimary py-2 px-4 rounded-t-lg font-medium" : "text-discord-textSecondary py-2 px-4 rounded-t-lg hover:bg-discord-primary hover:bg-opacity-50"}
            >
              Registros
            </TabsTrigger>
          </TabsList>
          
          <div className="bg-discord-secondary rounded-b-lg p-6 mb-8">
            <TabsContent value="configuration" className="space-y-6">
              <BotStatus status={botStatus} isLoading={isLoading} error={error} />
              <ConfigPanel />
            </TabsContent>
            
            <TabsContent value="permissions">
              <Card>
                <CardHeader>
                  <CardTitle>Configuración de Permisos</CardTitle>
                  <CardDescription>
                    Configura qué roles pueden usar los comandos del bot
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-discord-textSecondary">
                    El bot requiere los siguientes permisos:
                  </p>
                  <ul className="list-disc pl-5 pt-2 space-y-1 text-discord-textSecondary">
                    <li>Enviar Mensajes</li>
                    <li>Leer Historial de Mensajes</li>
                    <li>Usar Emojis Externos</li>
                    <li>Añadir Reacciones</li>
                    <li>Insertar Enlaces</li>
                    <li>Adjuntar Archivos</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="logs">
              <Card>
                <CardHeader>
                  <CardTitle>Registros del Bot</CardTitle>
                  <CardDescription>
                    Revisa la actividad reciente y errores del bot
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-discord-tertiary rounded-md p-2 font-mono text-sm text-discord-textSecondary">
                    <p>Los registros aparecerán aquí cuando el bot esté activo</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
        
        {/* Sección de Servidores */}
        <div className="mt-8">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-xl flex items-center">
                    <Server className="mr-2 h-5 w-5" /> 
                    Servidores
                  </CardTitle>
                  <CardDescription>
                    Visualiza y configura el bot para cada servidor
                  </CardDescription>
                </div>
                <Button 
                  variant="default" 
                  onClick={() => setLocation("/servers")}
                  className="bg-discord-blurple hover:bg-discord-blurple/80"
                >
                  Ver Servidores
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-discord-textSecondary">
                El panel de servidores te permite configurar el comportamiento del bot para cada servidor donde está instalado.
                Puedes definir canales específicos para notificaciones de pedidos y establecer permisos basados en roles.
              </p>
            </CardContent>
          </Card>
        </div>

        <footer className="text-discord-textSecondary text-center text-sm mt-8">
          <p>Configuración del Bot de Discord PokeStore © {new Date().getFullYear()} - Todos los derechos reservados</p>
        </footer>
      </div>
    </div>
  );
}
