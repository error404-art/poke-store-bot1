import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  AlertCircle, 
  Server,
  ChevronLeft,
  Save,
  Loader2,
  Users,
  Crown,
  Hash,
  Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";

// Schema para la configuración del servidor
const serverConfigSchema = z.object({
  guildId: z.string(),
  orderChannelId: z.string().optional(),
  requiredRoleId: z.string().optional()
});

type ServerConfigFormValues = z.infer<typeof serverConfigSchema>;

export default function ServerConfig() {
  const params = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Definimos interfaces para tipar correctamente
  interface ServerRole {
    id: string;
    name: string;
    color: string;
    position: number;
  }

  interface ServerChannel {
    id: string;
    name: string;
    type: number;
  }

  interface ServerConfig {
    id: number;
    guildId: string;
    orderChannelId?: string;
    requiredRoleId?: string;
  }

  interface ServerDetails {
    id: string;
    name: string;
    icon: string | null;
    memberCount: number;
    joined: string;
    owner: {
      id: string;
      tag: string;
    };
    textChannels: ServerChannel[];
    assignableRoles: ServerRole[];
    config: ServerConfig | null;
  }
  
  // Query para obtener los detalles del servidor
  const { 
    data: server, 
    isLoading, 
    error,
    isError 
  } = useQuery<ServerDetails>({
    queryKey: [`/api/servers/${params.id}`],
    enabled: !!params.id
  });

  // Form para la configuración del servidor
  const form = useForm<ServerConfigFormValues>({
    resolver: zodResolver(serverConfigSchema),
    defaultValues: {
      guildId: params.id,
      orderChannelId: '',
      requiredRoleId: ''
    }
  });

  // Actualizar form con valores del servidor cuando se carguen
  useEffect(() => {
    if (server?.config) {
      form.reset({
        guildId: server.id,
        orderChannelId: server.config.orderChannelId || '',
        requiredRoleId: server.config.requiredRoleId || ''
      });
    }
  }, [server, form]);

  // Mutación para guardar la configuración
  const saveConfig = useMutation({
    mutationFn: async (data: ServerConfigFormValues) => {
      return await apiRequest('/api/servers/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      toast({
        title: "Configuración guardada",
        description: "La configuración del servidor ha sido actualizada exitosamente.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/servers/${params.id}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
    },
    onError: (error) => {
      console.error("Error saving server config:", error);
      toast({
        title: "Error",
        description: "No se pudo guardar la configuración. Por favor, intenta nuevamente.",
        variant: "destructive"
      });
    }
  });

  // Manejar envío del formulario
  const onSubmit = (data: ServerConfigFormValues) => {
    saveConfig.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
        <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              className="mr-2" 
              onClick={() => setLocation("/servers")}
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Volver
            </Button>
            <h1 className="text-2xl font-bold">Cargando servidor...</h1>
          </div>
          
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-48 mb-2" />
              <Skeleton className="h-4 w-full" />
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-10 w-32" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (isError || !server) {
    return (
      <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
        <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              className="mr-2" 
              onClick={() => setLocation("/servers")}
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Volver
            </Button>
            <h1 className="text-2xl font-bold">Error</h1>
          </div>
          
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error al cargar el servidor</AlertTitle>
            <AlertDescription>
              No se pudo cargar la información del servidor. Por favor, intenta nuevamente.
            </AlertDescription>
          </Alert>
          
          <Button variant="default" onClick={() => window.location.reload()}>
            Recargar
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-discord-primary text-discord-textPrimary">
      <div className="container mx-auto p-4 lg:p-8 max-w-6xl">
        <div className="flex items-center mb-6">
          <Button 
            variant="ghost" 
            className="mr-2" 
            onClick={() => setLocation("/servers")}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Volver
          </Button>
          <h1 className="text-2xl font-bold">Configuración del Servidor</h1>
        </div>

        {/* Server Info Card */}
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <div className="flex items-center">
              {server.icon ? (
                <img 
                  src={server.icon} 
                  alt={server.name} 
                  className="h-16 w-16 rounded-full mr-4"
                />
              ) : (
                <div className="h-16 w-16 rounded-full bg-discord-blurple flex items-center justify-center mr-4">
                  <span className="text-white text-xl font-bold">
                    {server.name.substring(0, 2)}
                  </span>
                </div>
              )}
              <div>
                <CardTitle>{server.name}</CardTitle>
                <CardDescription className="flex items-center mt-1">
                  <Users className="h-4 w-4 mr-1" />
                  <span>{server.memberCount} miembros</span>
                  <Separator orientation="vertical" className="mx-2 h-4" />
                  <Crown className="h-4 w-4 mr-1" />
                  <span>Propietario: {server.owner.tag}</span>
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Configuration Form */}
        <Card>
          <CardHeader>
            <CardTitle>Configuración del Bot</CardTitle>
            <CardDescription>
              Personaliza cómo funciona el bot en este servidor
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="orderChannelId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Canal de Pedidos</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecciona un canal para notificaciones de pedidos" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {server.textChannels.map((channel) => (
                            <SelectItem key={channel.id} value={channel.id}>
                              <div className="flex items-center">
                                <Hash className="h-4 w-4 mr-1" />
                                {channel.name}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Canal donde se enviarán las notificaciones de nuevos pedidos.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="requiredRoleId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rol Requerido</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecciona un rol requerido para comandos" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {server.assignableRoles.map((role) => (
                            <SelectItem key={role.id} value={role.id}>
                              <div className="flex items-center">
                                <Shield className="h-4 w-4 mr-1" style={{ color: role.color }} />
                                {role.name}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Rol necesario para usar comandos administrativos (como /sell).
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={saveConfig.isPending}
                  className="flex items-center"
                >
                  {saveConfig.isPending ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Guardando...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Guardar Configuración
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}