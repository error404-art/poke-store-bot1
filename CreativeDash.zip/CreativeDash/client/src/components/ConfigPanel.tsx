import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { MessageSquare, Code, ExternalLink } from "lucide-react";

export default function ConfigPanel() {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Configuración de Comandos</CardTitle>
          <CardDescription>
            Configura el comando slash y el sistema de pedidos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-discord-primary p-4 rounded-lg mb-4">
            <div className="flex items-center mb-2">
              <span className="font-mono text-discord-blurple font-medium mr-2">/sell</span>
              <span className="text-discord-textSecondary text-sm">Muestra el mensaje de compra de la tienda</span>
            </div>
            
            <div className="mb-4">
              <label className="block text-discord-textSecondary text-sm mb-2">Permisos Requeridos</label>
              <div className="flex flex-wrap gap-2">
                <div className="bg-discord-tertiary py-1 px-3 rounded-full text-sm flex items-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                  CEO
                </div>
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-discord-textSecondary text-sm mb-2">Canal Objetivo</label>
              <div className="relative">
                <select className="w-full bg-discord-tertiary border border-black border-opacity-40 rounded py-2 px-3 text-discord-textPrimary appearance-none">
                  <option>#general</option>
                  <option>#commands</option>
                  <option>#bot-commands</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-discord-textSecondary">
                  <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                  </svg>
                </div>
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-discord-textSecondary text-sm mb-2">Canal de Notificación de Pedidos</label>
              <div className="relative">
                <select className="w-full bg-discord-tertiary border border-black border-opacity-40 rounded py-2 px-3 text-discord-textPrimary appearance-none">
                  <option>#orders</option>
                  <option>#sales</option>
                  <option>#staff-orders</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-discord-textSecondary">
                  <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                    <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue="preview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="preview">
            <MessageSquare className="h-4 w-4 mr-2" />
            Vista Previa de Mensajes
          </TabsTrigger>
          <TabsTrigger value="code">
            <Code className="h-4 w-4 mr-2" />
            Implementación
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="preview" className="space-y-4">
          <Accordion type="single" collapsible defaultValue="step1" className="w-full">
            <AccordionItem value="step1">
              <AccordionTrigger className="bg-discord-tertiary px-4 rounded-t-md">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-discord-blurple rounded-full flex items-center justify-center text-white mr-3">
                    <span className="text-sm font-bold">1</span>
                  </div>
                  <span>Respuesta de Comando Inicial</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="bg-discord-primary p-4 rounded-b-md border-t border-discord-tertiary">
                <div className="flex mb-2">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-discord-tertiary mr-3 overflow-hidden">
                    <div className="w-full h-full bg-discord-blurple flex items-center justify-center">
                      <span className="text-white text-sm font-bold">PS</span>
                    </div>
                  </div>
                  <div>
                    <div className="font-medium">PokeStore Bot</div>
                    <div className="text-discord-textSecondary text-xs">BOT</div>
                  </div>
                </div>
                
                <div className="border-l-4 border-[#FEE75C] bg-discord-tertiary px-3 py-2 mt-1 mb-2 rounded-sm">
                  <div className="font-medium mb-2">hola! 👋 Bienvenido al sistema de compra de la poke store</div>
                  <div className="text-sm mb-3">
                    Al momento de comprar aceptas estos términos y condiciones:
                  </div>
                  <div className="text-sm mb-1">1. No nos hacemos responsables por la crianza indebida</div>
                  <div className="text-sm mb-3">2. Ante cualquier estafa externo al servidor no nos hacemos cargo</div>
                  <div className="text-sm mb-2">Si estás de acuerdo dale click al botón de abajo</div>
                  <div className="text-discord-textSecondary text-xs">© poke store</div>
                </div>
                
                <div className="mt-1">
                  <Button variant="default" className="bg-[#57F287] hover:bg-opacity-80 text-white">
                    encargar 📦
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="step2">
              <AccordionTrigger className="bg-discord-tertiary px-4 rounded-t-md">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-discord-blurple rounded-full flex items-center justify-center text-white mr-3">
                    <span className="text-sm font-bold">2</span>
                  </div>
                  <span>Mensaje Privado</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="bg-discord-primary p-4 rounded-b-md border-t border-discord-tertiary">
                <div className="flex mb-2">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-discord-tertiary mr-3 overflow-hidden">
                    <div className="w-full h-full bg-discord-blurple flex items-center justify-center">
                      <span className="text-white text-sm font-bold">PS</span>
                    </div>
                  </div>
                  <div>
                    <div className="font-medium">PokeStore Bot</div>
                    <div className="text-discord-textSecondary text-xs">BOT</div>
                  </div>
                </div>
                
                <div className="mt-1 mb-3 text-discord-textPrimary">
                  hola Trainer123 👋! Bienvenido al sistema de compra de la poke store, bien para comprar debes de rellenar un formulario para saber que desea comprar y a quien se lo mandaremos
                </div>
                
                <div>
                  <Button variant="default" className="bg-[#57F287] hover:bg-opacity-80 text-white">
                    continuar
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="step3">
              <AccordionTrigger className="bg-discord-tertiary px-4 rounded-t-md">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-discord-blurple rounded-full flex items-center justify-center text-white mr-3">
                    <span className="text-sm font-bold">3</span>
                  </div>
                  <span>Formulario de Pedido</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="bg-discord-primary p-4 rounded-b-md border-t border-discord-tertiary">
                <div className="bg-discord-secondary rounded-md p-4">
                  <div className="border-b border-discord-tertiary pb-2 mb-4">
                    <h4 className="font-medium text-lg">Formulario de Compra</h4>
                    <p className="text-discord-textSecondary text-sm">Completa todos los campos para realizar tu pedido</p>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-discord-textSecondary text-sm mb-1">DISCORD</label>
                      <input type="text" className="w-full bg-discord-tertiary border border-black border-opacity-40 rounded py-2 px-3 text-discord-textPrimary" placeholder="Tu nombre de usuario de Discord" />
                    </div>
                    
                    <div>
                      <label className="block text-discord-textSecondary text-sm mb-1">Nombre de personaje en PokeMMO</label>
                      <input type="text" className="w-full bg-discord-tertiary border border-black border-opacity-40 rounded py-2 px-3 text-discord-textPrimary" placeholder="Nombre de tu personaje" />
                    </div>
                    
                    <div>
                      <label className="block text-discord-textSecondary text-sm mb-1">Edad</label>
                      <input type="number" className="w-full bg-discord-tertiary border border-black border-opacity-40 rounded py-2 px-3 text-discord-textPrimary" placeholder="Tu edad" />
                    </div>
                    
                    <div>
                      <label className="block text-discord-textSecondary text-sm mb-1">Producto que desea comprar</label>
                      <input type="text" className="w-full bg-discord-tertiary border border-black border-opacity-40 rounded py-2 px-3 text-discord-textPrimary" placeholder="Ej: Pokémon competitivo" />
                    </div>
                    
                    <div>
                      <label className="block text-discord-textSecondary text-sm mb-1">Cantidad</label>
                      <input type="number" className="w-full bg-discord-tertiary border border-black border-opacity-40 rounded py-2 px-3 text-discord-textPrimary" placeholder="Cantidad a comprar" />
                    </div>
                  </div>
                  
                  <div className="mt-4 flex justify-end space-x-2">
                    <Button variant="outline" className="bg-discord-tertiary hover:bg-opacity-80 text-discord-textPrimary border-none">
                      Cancelar
                    </Button>
                    <Button variant="default" className="bg-discord-blurple hover:bg-opacity-80 text-white">
                      Enviar Pedido
                    </Button>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="step4">
              <AccordionTrigger className="bg-discord-tertiary px-4 rounded-t-md">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-discord-blurple rounded-full flex items-center justify-center text-white mr-3">
                    <span className="text-sm font-bold">4</span>
                  </div>
                  <span>Confirmación de Usuario</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="bg-discord-primary p-4 rounded-b-md border-t border-discord-tertiary">
                <div className="flex mb-2">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-discord-tertiary mr-3 overflow-hidden">
                    <div className="w-full h-full bg-discord-blurple flex items-center justify-center">
                      <span className="text-white text-sm font-bold">PS</span>
                    </div>
                  </div>
                  <div>
                    <div className="font-medium">PokeStore Bot</div>
                    <div className="text-discord-textSecondary text-xs">BOT</div>
                  </div>
                </div>
                
                <div className="mt-1 text-discord-textPrimary">
                  Gracias por comprar en nuestra tienda! Te avisaremos cuando tengamos tu pedido (aproximadamente son 4 días de demora)
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="step5">
              <AccordionTrigger className="bg-discord-tertiary px-4 rounded-t-md">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-discord-blurple rounded-full flex items-center justify-center text-white mr-3">
                    <span className="text-sm font-bold">5</span>
                  </div>
                  <span>Notificación para Staff</span>
                </div>
              </AccordionTrigger>
              <AccordionContent className="bg-discord-primary p-4 rounded-b-md border-t border-discord-tertiary">
                <div className="flex mb-2">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-discord-tertiary mr-3 overflow-hidden">
                    <div className="w-full h-full bg-discord-blurple flex items-center justify-center">
                      <span className="text-white text-sm font-bold">PS</span>
                    </div>
                  </div>
                  <div>
                    <div className="font-medium">PokeStore Bot</div>
                    <div className="text-discord-textSecondary text-xs">BOT</div>
                  </div>
                </div>
                
                <div className="border-l-4 border-[#57F287] bg-discord-tertiary px-3 py-2 mt-1 mb-2 rounded-sm">
                  <div className="font-medium mb-2">Han realizado un encargo 🎉</div>
                  <div className="text-sm mb-2">
                    El usuario <span className="font-medium">Trainer123</span> a solicitado un encargo. A continuación la información del pedido:
                  </div>
                  <div className="text-sm mb-1"><span className="font-medium">Producto:</span> Charmander Perfect IVs</div>
                  <div className="text-sm mb-1"><span className="font-medium">Cantidad:</span> 3</div>
                  <div className="text-sm mb-2"><span className="font-medium">Personaje de pokeMMO:</span> AshKetchum99</div>
                  <div className="text-sm">Si el pedido está listo para ser entregado pulsa el botón de abajo para pedir un precio e informar</div>
                </div>
                
                <div className="mt-1">
                  <Button variant="default" className="bg-[#FEE75C] hover:bg-opacity-80 text-black">
                    Avisar 📢
                  </Button>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </TabsContent>
        
        <TabsContent value="code">
          <Card>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                Código de Implementación de Discord.js
                <Button variant="outline" size="sm">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Ver Código Completo
                </Button>
              </CardTitle>
              <CardDescription>
                Implementación de la funcionalidad del bot de Discord
              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="bg-discord-tertiary rounded-md p-4 font-mono text-sm overflow-x-auto text-discord-textPrimary">
{`// Main bot implementation
import { Client, GatewayIntentBits, Events, 
         EmbedBuilder, ButtonBuilder, ButtonStyle, 
         ActionRowBuilder } from 'discord.js';

const client = new Client({ 
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
  ],
});

client.once('ready', () => {
  console.log('Bot is online!');
  // Register slash commands
});

// Handle /sell command
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  
  if (interaction.commandName === 'sell') {
    // Check if user has CEO role
    const hasCEORole = interaction.member.roles.cache
      .some(role => role.name === 'CEO');
    
    if (!hasCEORole) {
      return interaction.reply({
        content: 'Solo usuarios con el rol CEO pueden usar este comando.',
        ephemeral: true
      });
    }
    
    // Create embed message with terms and yellow color
    const embed = new EmbedBuilder()
      .setColor('#FEE75C')
      .setTitle('hola! 👋 Bienvenido al sistema de compra de la poke store')
      // ...more embed configuration
    
    // Create green button
    const orderButton = new ButtonBuilder()
      .setCustomId('order')
      .setLabel('encargar 📦')
      .setStyle(ButtonStyle.Success);
    
    const actionRow = new ActionRowBuilder().addComponents(orderButton);
    
    await interaction.reply({ embeds: [embed], components: [actionRow] });
  }
});

// Rest of implementation...
`}
              </pre>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
