import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { CircleCheck, CircleX, Server, User, Clock } from "lucide-react";

interface BotStatusProps {
  status: any;
  isLoading: boolean;
  error: any;
}

export default function BotStatus({ status, isLoading, error }: BotStatusProps) {
  // Format uptime from milliseconds to human-readable format
  const formatUptime = (ms: number) => {
    if (!ms) return "N/A";
    
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    return `${days}d ${hours % 24}h ${minutes % 60}m ${seconds % 60}s`;
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          Estado del Bot
          {!isLoading && !error && (
            <Badge variant={status?.connected ? "default" : "destructive"}>
              {status?.connected ? "Conectado" : "Desconectado"}
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          Estado actual e información sobre el bot de Discord
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        ) : error ? (
          <div className="text-destructive flex items-center">
            <CircleX className="h-5 w-5 mr-2" />
            Error al obtener el estado del bot
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-2">
                {status?.connected ? (
                  <CircleCheck className="h-5 w-5 text-green-500" />
                ) : (
                  <CircleX className="h-5 w-5 text-red-500" />
                )}
                <span className="text-discord-textPrimary">
                  {status?.connected ? "Bot Conectado" : "Bot Desconectado"}
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-discord-textSecondary" />
                <span className="text-discord-textPrimary">
                  {status?.username || "N/A"}
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Server className="h-5 w-5 text-discord-textSecondary" />
                <span className="text-discord-textPrimary">
                  {status?.guilds || 0} servidores
                </span>
              </div>
            </div>
            
            {status?.connected && (
              <div className="flex items-center space-x-2 pt-2 border-t border-discord-tertiary">
                <Clock className="h-5 w-5 text-discord-textSecondary" />
                <span className="text-discord-textPrimary">
                  Tiempo activo: {formatUptime(status.uptime)}
                </span>
              </div>
            )}
            
            {!status?.connected && import.meta.env.VITE_DISCORD_BOT_TOKEN && (
              <div className="text-discord-textSecondary text-sm mt-2">
                El bot está configurado pero no conectado. Verifica el estado de la API de Discord o tu token de bot.
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
